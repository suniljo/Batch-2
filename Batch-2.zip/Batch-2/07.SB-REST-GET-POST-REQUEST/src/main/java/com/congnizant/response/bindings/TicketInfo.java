package com.congnizant.response.bindings;

import javax.xml.bind.annotation.XmlRootElement;

import lombok.Data;

@Data
@XmlRootElement
public class TicketInfo {
 private Long ticketno;
 private String ticketstatus;
 private Float ticketprice;
 private String from;
 private String to;
 private String bookeddate;
 private String journeydate;
 private String name;
 private Integer trainNo;
}
