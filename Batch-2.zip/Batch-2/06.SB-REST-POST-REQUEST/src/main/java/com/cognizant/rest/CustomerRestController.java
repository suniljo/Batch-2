package com.cognizant.rest;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.congnizant.bindings.Customer;

@RestController
@RequestMapping("/customer")
public class CustomerRestController {
  @PostMapping(
		        path = "/add",
		        consumes = {"application/xml","application/json"}
		      )	
  public ResponseEntity<String> addCustomer(@RequestBody Customer customer){
	  System.out.println(customer);
	  //logic to save Customer details in DB
	  return new ResponseEntity<String>("Customer Informations are saved Successfully", HttpStatus.CREATED);
  }
}
