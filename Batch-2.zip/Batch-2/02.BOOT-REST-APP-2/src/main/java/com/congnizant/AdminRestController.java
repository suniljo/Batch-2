package com.congnizant;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class AdminRestController {
 @GetMapping("/welcome")	
 public String welcomeMsgGet() {
	 String msg = "Welcome from GET";
	 return msg;
 }
 
 @PostMapping("/welcome")
 public String welcomeMsgPostt() {
	 String msg = "Welcome from POST";
	 return msg;
 }
 
 @PutMapping("/welcome")
 public String welcomeMsgPut() {
	 String msg = "Welcome from PUT";
	 return msg;
 }
 
 @DeleteMapping("/welcome")
 public String welcomeMsgDelete() {
	 String msg = "Welcome from DELETE HTTP Method";
	 return msg;
 }
}
