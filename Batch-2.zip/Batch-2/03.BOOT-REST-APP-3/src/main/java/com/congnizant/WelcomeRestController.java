package com.congnizant;

import java.util.Calendar;
import java.util.Date;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class WelcomeRestController {
  @GetMapping("/welcome")	
  public String welcomeMessage() {
	  String msg = "Welcome to Cognizant";
	  try {
		  Thread.sleep(6000);
	  }catch(Exception ex) {
		  ex.printStackTrace();
	  }
	  return msg;
  }
  
  @GetMapping("/date")
  public Date getDate() {
	  return new Date();
  }
  
  @GetMapping("/today")
  public String getToday() {
	  Calendar cal = Calendar.getInstance();
	  Date today = cal.getTime();
	  String dateStr = cal.get(Calendar.DATE)+"-"+(cal.get(Calendar.MONTH)+1)+"-"+cal.get(Calendar.YEAR);
	  return dateStr;
  }
  
  @GetMapping("/response")
  public ResponseEntity<String> sendResponse(){
	  //ResponseEntity<String> responseEntity = new ResponseEntity<String>("This is response Message", HttpStatus.OK);
	  //ResponseEntity<String> responseEntity = new ResponseEntity<String>("Information is Saved in Database", HttpStatus.CREATED);
	  //ResponseEntity<String> responseEntity = new ResponseEntity<String>("Sorry Boss, This is a bad request", HttpStatus.BAD_REQUEST);
	  
	  /*---to send response headers ---*/
	  HttpHeaders headers = new HttpHeaders();
	  headers.add("company-name", "Cognizant");	  
	  ResponseEntity<String> responseEntity = new ResponseEntity<String>("This response contains response header with status and body", headers ,HttpStatus.CREATED);
	  return responseEntity;
  }
  //to read request head data and request body data
  @PostMapping("/head")
  public String getDataFromRequest(@RequestHeader(name = "name", required = false, defaultValue = "123") String names, @RequestHeader("Content-Type") String ctype, @RequestBody String dataFromConsumer) {
	  String responseMsg = null;
	  responseMsg = "Header Details>>>\nname: "+names+"\nContent-Type: "+ctype+"\nData in Request: "+dataFromConsumer;
	  return responseMsg;
  }
}
