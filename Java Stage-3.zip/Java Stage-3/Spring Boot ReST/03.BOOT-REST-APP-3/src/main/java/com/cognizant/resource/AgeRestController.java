package com.cognizant.resource;

import java.util.Calendar;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/personal")
public class AgeRestController {
	@GetMapping("/age")
	public ResponseEntity<String> getAge(@RequestParam("yob") int yob) {
		if (isYearOfBirthValid(yob)) {
			int age = calculateAge(yob);
			ResponseEntity<String> resEntity = new ResponseEntity<>("Your Age is " + age, HttpStatus.OK);
			return resEntity;
		}
		return new ResponseEntity<>("Year of Birth should not be in Future, You given as " + yob,
				HttpStatus.BAD_REQUEST);		
	}

	private int calculateAge(int yob) {
		// get the current year
		Calendar cal = Calendar.getInstance();
		int currentYear = cal.get(Calendar.YEAR);
		return currentYear-yob;
	}

	private boolean isYearOfBirthValid(int yob) {
		// get the current year
		Calendar cal = Calendar.getInstance();
		int currentYear = cal.get(Calendar.YEAR);
		return currentYear > yob;
	}
}
