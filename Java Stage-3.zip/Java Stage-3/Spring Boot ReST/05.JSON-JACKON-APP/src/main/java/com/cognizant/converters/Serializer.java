package com.cognizant.converters;

import java.io.File;
import java.io.IOException;

import com.cognizant.entity.Customer;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;

public class Serializer {

	public static void main(String[] args) throws IOException {
		//step-1 create a Customer instance
		Customer customer = new Customer();
		customer.setCustomerId(101);
		customer.setCustomerName("Naveen");
		//customer.setCustomerEmail("naveen@gmail.com");
		
		//step-2 Performing Serialization
		ObjectMapper objMapper = new ObjectMapper();
		
		//convert customer object to a JSON String
		String jsonString = objMapper.writeValueAsString(customer);
		System.out.println(jsonString);
		
		ObjectWriter objWriter = objMapper.writerWithDefaultPrettyPrinter();
		jsonString = objWriter.writeValueAsString(customer);
		System.out.println(jsonString);
		
		//objMapper.writeValue(new File("target/customer.json"), customer);
		objMapper
			.writerWithDefaultPrettyPrinter()
			.writeValue(new File("target/customer.json"), customer);
	}
}
