package com.cognizant.converters;

import java.io.File;
import com.cognizant.entity.Customer;
import com.fasterxml.jackson.databind.ObjectMapper;

public class Deserializer {

	public static void main(String[] args) throws Exception {
		File file = new File("target/customer.json");
		if(file.exists()) {
			//perform deserialization for JSON data in customer.json
			ObjectMapper mapper = new ObjectMapper();
			Customer customer = mapper.readValue(file, Customer.class);
			System.out.println(customer); //toString()
		}
		else {
			System.out.println("JSON data not available!");
		}
	}
}
