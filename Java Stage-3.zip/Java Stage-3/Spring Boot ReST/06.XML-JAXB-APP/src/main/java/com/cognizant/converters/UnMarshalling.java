package com.cognizant.converters;

import java.io.File;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.Unmarshaller;

import com.cognizant.bindings.Customer;

public class UnMarshalling {

	public static void main(String[] args) throws Exception {
		File file = new File("target/customer.xml"); 
		
		JAXBContext context = JAXBContext.newInstance(Customer.class);
		Unmarshaller unmarshaller = context.createUnmarshaller();
		Customer cust = (Customer) unmarshaller.unmarshal(file);
		System.out.println(cust);
	}
}
