package com.cognizant.converters;

import java.io.File;
import java.io.StringWriter;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.Marshaller;

import com.cognizant.bindings.Customer;

public class Marshalling {

	public static void main(String[] args) throws Exception {
		//Step-1 Create the Domain Model
		Customer customer = new Customer();
		customer.setCustomerId(101);
		customer.setCustomerName("Sunil Joseph");
		customer.setCustomerEmail("sunil@gmail.com");
		
		//Step-2 Convert the Domain Model to XML (Marshalling)
		JAXBContext context = JAXBContext.newInstance(Customer.class);
		Marshaller marshaller = context.createMarshaller();
		marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
		marshaller.marshal(customer, new File("target/customer.xml"));
		System.out.println("Marshalling done. customer.xml is available in /target");
		
		StringWriter xmlWriter = new StringWriter();
		marshaller.marshal(customer, xmlWriter);
		System.out.println(xmlWriter.toString());
	}
}
